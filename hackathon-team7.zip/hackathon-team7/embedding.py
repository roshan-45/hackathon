from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Function to read the log file
def read_log_file(file_path):
    try:
        log_lines = []
        with open(file_path, 'r') as log_file:
            for line in log_file:
                line = line.strip() 
                if line.endswith("\\"):  
                    line = line[:-1]
                log_lines.append(line)
        return log_lines
    except Exception as e:
        return f"Error reading log file: {e}"

# Function to parse log lines with context
def parse_log_lines_with_context(log_lines, context_size=1):
    parsed_logs = []
    for i, line in enumerate(log_lines):
        
        parts = line.split('\t')
        
        if len(parts) >= 5:
            timestamp = parts[0]  # Timestamp
            process_id = parts[1]  # Process ID (0)
            log_level = parts[2]   # Log level (Debug or Error)
            category = parts[3]    # Category or context (Diag)
            details = parts[4]     # Remaining details (e.g., 7881|7878|...)

            parsed_logs.append({
                'timestamp': timestamp,
                'process_id': process_id,
                'log_level': log_level,
                'category': category,
                'details': details,
                'original_line': line  # Store the original line for reference
            })

            
            if log_level == "Error" or "Warning" in details:
                # Capture context above and below
                context_start = max(i - context_size, 0)
                context_end = min(i + context_size + 1, len(log_lines))
                for j in range(context_start, context_end):
                    if j != i:  # Avoid duplicating the current log entry
                        context_line = log_lines[j].strip()  # Strip whitespace
                        # Store the context line or do something with it
                        print(f"Context for {line.strip()}: {context_line}")
    return parsed_logs

# Function to retrieve relevant context based on a query
def retrieve_relevant_context(query, log_entries, embeddings):
    query_embedding = embedding_model.encode(query, convert_to_tensor=True)
    similarities = cosine_similarity(query_embedding.reshape(1, -1), embeddings)
    
    # Get the index of the most similar log entry
    most_similar_index = np.argmax(similarities)
    
    # Return the corresponding log entry and its context
    relevant_log = log_entries[most_similar_index]
    context = get_context_lines(parsed_data, relevant_log, context_size=1)  # Adjust context size as needed
    return relevant_log, context

# Function to extract context lines based on keyword
def get_context_lines(parsed_data, keyword, context_size=1):
    context_lines = []
    for i, entry in enumerate(parsed_data):
        if keyword in entry['log_level']:  # Check if keyword exists in the details
            # Get lines above and below the current entry
            start_index = max(i - context_size, 0)
            end_index = min(i + context_size + 1, len(parsed_data))
            context = parsed_data[start_index:end_index]
            context_lines.extend(context)
    return context_lines


log_file_path = 'logFiles/APP01/skully.log' 
log_lines = read_log_file(log_file_path)

# Parse the log lines while capturing relevant context
parsed_data = parse_log_lines_with_context(log_lines, context_size=1)

# Load a pre-trained embedding model
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Create embeddings for each log entry
log_entries = ["{} | {} | {}".format(entry['timestamp'], entry['process_id'], entry['details']) for entry in parsed_data]
embeddings = embedding_model.encode(log_lines, convert_to_tensor=True)


# Example query to retrieve relevant context
user_query = "Why I am getting error"  # Replace with your query
relevant_log, context = retrieve_relevant_context(user_query, log_entries, embeddings)

# Print the retrieved log and context
print("Relevant Log Entry:", relevant_log)
print("Context Lines:", context)
 
for entry in context:
    print(entry)