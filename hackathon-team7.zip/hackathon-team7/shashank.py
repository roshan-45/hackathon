import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from InstructorEmbedding import INSTRUCTOR

from transformers import AutoModel, AutoTokenizer

# Load the tokenizer and model using the huggingface 'transformers' library
tokenizer = AutoTokenizer.from_pretrained('hkunlp/instructor-large')
model = AutoModel.from_pretrained('hkunlp/instructor-large')

# Load the model
model = INSTRUCTOR('hkunlp/instructor-large')
# Function to generate embeddings for log messages
def generate_log_embeddings(log_messages):
    embeddings = []
    # Loop through log messages and generate embeddings based on instruction
    for log in log_messages:
        # Determine the instruction based on the log content
        if "error" in log.lower():
            instruction = "Represent the log message as an error:"
        elif "warning" in log.lower():
            instruction = "Represent the log message as a warning:"
        else:
            instruction = "Represent the log message:"
        # Generate embedding for each log message
        embedding = model.encode([[instruction, log]])
        embeddings.append(embedding)
    return embeddings
# Function to read log messages from a log file
def read_log_file(filepath):
    try:
        with open(filepath, "r") as file:
            log_messages = file.readlines()  # Read all lines from the log file
        return log_messages
    except Exception as e:
        print(f"Error reading log file: {e}")
        return []
# Function to process log file and extract embeddings for errors
def process_log_file(log_file_path):
    # Read log messages from the file
    log_messages = read_log_file(log_file_path)
    # Generate embeddings for the log messages
    log_embeddings = generate_log_embeddings(log_messages)
    # Print embeddings for logs containing 'error'
    for i, embedding in enumerate(log_embeddings):
        if "error" in log_messages[i].lower():
            print(f"Embedding for log {i + 1}: {embedding}")
# Example usage
if __name__ == "__main__":
    # Replace this with the path to your log file
    log_file_path = "logFiles/APP01/skully.log"
    # Process the log file to generate and print embeddings for error messages
    process_log_file(log_file_path)