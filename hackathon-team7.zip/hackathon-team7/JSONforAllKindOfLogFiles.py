import json
from datetime import datetime
file_path = "logFiles/APP01/skully.log.bak.1"
log_entries = {}
l =0

with open(file_path) as fh:
    headers =['date', 'timestamp', 'project_id', 'status','information']
    for line in fh:
        description = list( line.strip().split(None, 4))
        if description==[]:
            continue
        if (l>0):
            txt_str = description[0]
            format = "%Y-%m-%d"
            try:
                res = bool(datetime.strptime(txt_str, format))
            except ValueError:
                log_entries['log'+str(l-1)]['information'] = log_entries['log'+str(l-1)]['information']+line
                continue
        log_entry = {headers[i]:description[i] for i in range(len(description))}
        sno ='log'+str(l)
        log_entries[sno]=log_entry
        l=l+1

out_file = open("required_format.json", "w")
json.dump(log_entries, out_file, indent = 5)
out_file.close()